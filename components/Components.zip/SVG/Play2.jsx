import React from "react";

const Play2 = () => {
  return <div>Play2</div>;
};

export default Play2;
